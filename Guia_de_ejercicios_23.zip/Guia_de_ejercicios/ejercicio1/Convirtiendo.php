<?php

class Grados{
    public $CentigradosF;
    public function __construct($_CentigradosF)
    {
        $this->CentigradosF = $_CentigradosF;
    }
    public function Conversion()
    {
        echo " La conversion de centigrados a farenheit es : ".$this->CentigradosF * 9/5+32;
    }
    
}
$Resultado = new Grados($_POST['numero1']);
$Resultado->Conversion();

?>