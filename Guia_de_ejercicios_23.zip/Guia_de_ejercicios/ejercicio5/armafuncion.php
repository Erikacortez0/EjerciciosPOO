<?php
class Pistola extends Arma {
    public function __construct() {
        parent::__construct("Pistola", 0);
    }
}

class Rifle extends Arma {
    public function __construct() {
        parent::__construct("Rifle", 0);
    }
}

class Escopeta extends Arma {
    public function __construct() {
        parent::__construct("Escopeta", 0);
    }
}

class Arco extends Arma {
    public function __construct() {
        parent::__construct("Arco", 0);
    }
}
?>