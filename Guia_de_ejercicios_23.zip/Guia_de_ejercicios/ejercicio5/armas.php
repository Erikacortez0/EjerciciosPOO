<?php
class Arma {
    protected $tipo;
    protected $balas;

    public function __construct($tipo, $balas) {
        $this->tipo = $tipo;
        $this->balas = $balas;
    }

    public function recargar() {
        $this->balas += 8;
    }

    public function disparar() {
        if ($this->balas > 0) {
            $this->balas--;
        }
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getBalas() {
        return $this->balas;
    }
}
?>