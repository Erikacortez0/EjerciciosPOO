<?php
class Juegos{
    public $numeros;
    public $precios;

    public function __construct($_numeros,$_precios)
    {
        $this->numeros = $_numeros;
        $this->precios = $_precios;
    }

    public function Jugando(){
        if($this->numeros == 1)
        {
            if ($this->precios == 63)
            {
                echo "<h1>FELICIDADES USTED HA GANADO $70</h1>";
            }
            else if($this->numeros > 100)
            {
                echo "<h1>ERROR, POR FAVOR INGRESE UN NUMERO VALIDO</h1>";
            }
            else
            {
                echo "<h1>LO SENTIMOS USTED HA PERDIDO, SUERTE A LA PROXIMA</h1>";
            }
        }

        else if($this->precios == 2)
        {
            if ($this->numeros == 15)
            {
                echo "<h1>FELICIDADES USTED HA GANADO $140</h1>";
            }
            else if($this->numeros > 100)
            {
                echo "<h1>ERROR, POR FAVOR INGRESE UN NUMERO VALIDO</h1>";
            }
            else
            {
                echo "<h1>LO SENTIMOS USTED HA PERDIDO, SUERTE A LA PROXIMA</h1>";
            }
        }
        else if($this->precios == 3)
        {
            if ($this->numeros == 28)
            {
                echo "<h1>FELICIDADES USTED HA GANADO $210</h1>";
            }
            else if($this->numeros > 100)
            {
                echo "<h1>ERROR, POR FAVOR INGRESE UN NUMERO VALIDO</h1>";
            }
            else
            {
                echo "<h1>LO SENTIMOS USTED HA PERDIDO, SUERTE A LA PROXIMA</h1>";
            }
        }
        else if($this->precios == 4)
        {
            if ($this->numeros == 81)
            {
                echo "<h1>FELICIDADES USTED HA GANADO $280</h1>";
            }
            else if($this->numeros > 100)
            {
                echo "<h1>ERROR, POR FAVOR INGRESE UN NUMERO VALIDO</h1>";
            }
            else
            {
                echo "<h1>LO SENTIMOS USTED HA PERDIDO, SUERTE A LA PROXIMA</h1>";
            }
        }
        else if($this->precios == 5)
        {
            if ($this->numeros == 20)
            {
                echo "<h1>FELICIDADES USTED HA GANADO $350</h1>";
            }
            else if($this->numeros > 100)
            {
                echo "<h1>ERROR, POR FAVOR INGRESE UN NUMERO VALIDO</h1>";
            }
            else
            {
                echo "<h1>LO SENTIMOS USTED HA PERDIDO, SUERTE A LA PROXIMA</h1>";
            }
        }
        else if($this->precios == 6)
        {
            if ($this->numeros == 98)
            {
                echo "<h1>FELICIDADES USTED HA GANADO $420</h1>";
            }
            else if($this->numeros > 100)
            {
                echo "<h1>ERROR, POR FAVOR INGRESE UN NUMERO VALIDO</h1>";
            }
            else
            {
                echo "<h1>LO SENTIMOS USTED HA PERDIDO, SUERTE A LA PROXIMA</h1>";
            }
        }
        else if($this->precios == 7)
        {
            if ($this->numeros == 77)
            {
                echo "<h1>FELICIDADES USTED HA GANADO $490</h1>";
            }
            else if($this->numeros > 100)
            {
                echo "<h1>ERROR, POR FAVOR INGRESE UN NUMERO VALIDO</h1>";
            }
            else
            {
                echo "<h1>LO SENTIMOS USTED HA PERDIDO, SUERTE A LA PROXIMA</h1>";
            }
        }
        else if($this->precios == 8)
        {
            if ($this->numeros== 43)
            {
                echo "<h1>FELICIDADES USTED HA GANADO $560</h1>";
            }
            else if($this->numeros > 100)
            {
                echo "<h1>ERROR, POR FAVOR INGRESE UN NUMERO VALIDO</h1>";
            }
            else
            {
                echo "<h1>LO SENTIMOS USTED HA PERDIDO, SUERTE A LA PROXIMA</h1>";
        }
        }
            else if($this->precios == 9)
            {
                if ($this->numeros == 79)
                {
                    echo "<h1>FELICIDADES USTED HA GANADO $630</h1>";
                }
                else if($this->numeros > 100)
                {
                    echo "<h1>ERROR, POR FAVOR INGRESE UN NUMERO VALIDO</h1>";
                }
                else
                {
                    echo "<h1>LO SENTIMOS USTED HA PERDIDO, SUERTE A LA PROXIMA</h1>";
                }
            }
            else if($this->precios == 10)
            {
                if ($this->numeros == 52)
                {
                    echo "<h1>FELICIDADES USTED HA GANADO $700</h1>";
                }
                else if($this->numeros > 100)
                {
                    echo "<h1>ERROR, POR FAVOR INGRESE UN NUMERO VALIDO</h1>";
                }
                else
                {
                    echo "<h1>LO SENTIMOS USTED HA PERDIDO, SUERTE A LA PROXIMA</h1>";
                }
                
            }
            else
            {
                echo "<h1>ERROR, POR FAVOR INGRESE UN NUMERO DE ENTRADA VALIDA</h1>";
            }
      
    }

}

$objeto = new Juegos($_POST['precios'], $_POST['numeros']);
$objeto->Jugando();
?>