<?php
class imagenes{
    public function imagen(){
        if($_SERVER["REQUEST_METHOD"] == "POST"){
            for($i = 1; $i <= $_POST["numero"]; $i ++){
                echo '<img src="img/Sanji.jpg" width="500" height="600">';
                echo '<br>';
            }
        }
    }
}

$imagen = new imagenes();
$imagen->imagen();
?>