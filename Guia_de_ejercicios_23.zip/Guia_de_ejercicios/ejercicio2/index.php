<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h4>Evaluar la temperatura</h4>
    <form method="POST" action="EvaluarTemperatura.php">
        <label><h3>TemperaturaCentigrados</h3></label>
        <input type="number" name="Temperatura_Grados" require placeholder="Digite la temperatura">
        <br><br>
        <input type="submit" value="Evaluar temperatura">
         
    </form>
</body>
</html>