<?php

Class Temperatura_grados{
    public $Temperatura_centigrado;

    public function __construct($_Temperaturacentigrado)
    {
        $this->Temperatura_centigrado = $_Temperaturacentigrado;
    }

    public function temperatura_grados()
    {
        if ($this->Temperatura_centigrado <= 0){
            echo " <p style='color:blue'>Temperatura maximamente fria</p> ";

        }

        else if($this->Temperatura_centigrado > 0 && $this->Temperatura_centigrado <=30){
            echo "<p style='color:yellow'> Temperatura estable</p>"; 
        }

        else if($this->Temperatura_centigrado >= 31 && $this->Temperatura_centigrado <=100){
            echo "<p style='color:red'> Temperatura maximamente caliente</p>"; 
        }

        else{
            echo "<p>Ingrese valores validos</p>";
        }
    }
}

$valor= new Temperatura_grados(($_POST['Temperatura_Grados']));
$valor->temperatura_grados();
 
?>